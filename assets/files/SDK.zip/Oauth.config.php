<?php
/**
 * 彩虹聚合登录SDK
 * 1.0
**/

// API地址
$Oauth_config['apiurl'] = 'https://u.cccyun.cc/';

// APPID
$Oauth_config['appid'] = '1000';

// APPKEY
$Oauth_config['appkey'] = '1111111111111111111111111111';

// 登录成功返回地址
$Oauth_config['callback'] = 'http://127.0.0.1/SDK/connect.php';
